import React, { Component } from 'react';

class TabSideBarItem extends Component {
  render() {
    return (
      <div>
        This is a sidebar
      </div>
    )
  }
}

export default TabSideBarItem
